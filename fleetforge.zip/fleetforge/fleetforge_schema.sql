-- ============================================================
-- FleetForge — core data model (PostgreSQL)
-- Device-logistics platform: HRIS-driven onboarding/offboarding,
-- inventory, shipping/returns, repairs, and warehouse scanning.
--
-- Mental model:
--   HRIS (Rippling/BambooHR/UKG) = source of truth for PEOPLE
--   FleetForge                   = source of truth for HARDWARE
--   The two are kept in sync; people-events drive hardware-workflows.
-- ============================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- for gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS citext;      -- case-insensitive email

-- ========== ENUMS ==========
CREATE TYPE device_type     AS ENUM ('laptop','phone','monitor','tablet','accessory');
CREATE TYPE device_status   AS ENUM ('in_stock','building','ready','deployed',
                                      'in_transit','returning','received',
                                      'wiping','in_repair','retired');
CREATE TYPE request_type     AS ENUM ('onboarding','offboarding','monitor_send','repair','adhoc');
CREATE TYPE request_status   AS ENUM ('open','in_progress','blocked','completed','cancelled');
CREATE TYPE shipment_kind    AS ENUM ('outbound_build','return_box','forwarding');
CREATE TYPE shipment_status  AS ENUM ('label_created','in_transit','delivered','received','exception');
CREATE TYPE hris_provider    AS ENUM ('rippling','bamboohr','ukg','workday','manual');
CREATE TYPE repair_status    AS ENUM ('reported','quoted','approved','in_repair','resolved','unrepairable');

-- ========== TENANTS / CLIENTS ==========
-- The companies FleetForge serves. Rippling is one client among many.
CREATE TABLE clients (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text NOT NULL,                       -- e.g. 'Rippling'
  is_rippling   boolean NOT NULL DEFAULT false,       -- drives the Rippling / Non-Rippling split on the dashboard
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- One HRIS connection per client. NEVER store raw tokens here —
-- store a reference to a secret kept in a secrets manager (Vault/KMS).
CREATE TABLE hris_connections (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id          uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  provider           hris_provider NOT NULL,
  external_org_id    text,            -- org id in the HRIS / unified API (Finch, Merge, etc.)
  credential_ref     text,            -- pointer into your secrets manager, not the token itself
  webhook_secret_ref text,
  last_synced_at     timestamptz,
  status             text NOT NULL DEFAULT 'active',
  created_at         timestamptz NOT NULL DEFAULT now()
);

-- FleetForge's own operators (warehouse / ops staff) — NOT client employees.
CREATE TABLE staff_users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email         citext UNIQUE NOT NULL,
  full_name     text NOT NULL,
  role          text NOT NULL DEFAULT 'operator',     -- operator | admin
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- ========== PEOPLE (synced from HRIS) ==========
CREATE TABLE end_users (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id         uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  hris_external_id  text,             -- the employee id in Rippling, etc.
  full_name         text NOT NULL,
  email             citext,
  employment_status text,             -- active | terminated | pending (mirrors the HRIS)
  start_date        date,
  end_date          date,
  ship_address      jsonb,            -- home/work address used for builds & return boxes
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  UNIQUE (client_id, hris_external_id)
);

-- ========== INVENTORY ==========
CREATE TABLE bins (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  qr_code       text UNIQUE NOT NULL,  -- scanned in the "Bin" scan flow
  label         text,                  -- e.g. 'Aisle 3 / Shelf B'
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE devices (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id        uuid REFERENCES clients(id) ON DELETE SET NULL,   -- owning client
  asset_tag        text UNIQUE,        -- scanned in the "Asset Tag" flow
  serial_number    text UNIQUE,        -- scanned in the "Serial Number" flow
  device_type      device_type NOT NULL,
  make             text,
  model            text,
  status           device_status NOT NULL DEFAULT 'in_stock',
  assigned_user_id uuid REFERENCES end_users(id) ON DELETE SET NULL,
  bin_id           uuid REFERENCES bins(id) ON DELETE SET NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

-- ========== WORKFLOW: REQUESTS ==========
-- Created automatically from HRIS lifecycle events (status -> active /
-- termination), or manually by an operator.
CREATE TABLE requests (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id     uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  end_user_id   uuid REFERENCES end_users(id) ON DELETE SET NULL,
  type          request_type NOT NULL,
  status        request_status NOT NULL DEFAULT 'open',
  device_id     uuid REFERENCES devices(id) ON DELETE SET NULL,
  source        text NOT NULL DEFAULT 'hris',         -- hris | manual | api
  due_date      date,
  created_at    timestamptz NOT NULL DEFAULT now(),
  completed_at  timestamptz
);

-- ========== SHIPPING (builds out, return boxes in) ==========
CREATE TABLE shipments (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id       uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  request_id      uuid REFERENCES requests(id) ON DELETE SET NULL,
  end_user_id     uuid REFERENCES end_users(id) ON DELETE SET NULL,
  device_id       uuid REFERENCES devices(id) ON DELETE SET NULL,
  kind            shipment_kind NOT NULL,
  box_type        text,               -- the "Box Type" column on return-box cards
  carrier         text,               -- ups | fedex | usps
  tracking_number text,               -- the "Tracking" column on the dashboard
  label_url       text,               -- prepaid label from EasyPost / Shippo
  status          shipment_status NOT NULL DEFAULT 'label_created',
  to_address      jsonb,
  from_address    jsonb,
  created_at      timestamptz NOT NULL DEFAULT now(),
  delivered_at    timestamptz
);

-- ========== REPAIRS ==========
CREATE TABLE repairs (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id     uuid NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
  client_id     uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  end_user_id   uuid REFERENCES end_users(id) ON DELETE SET NULL,
  issue         text NOT NULL,
  status        repair_status NOT NULL DEFAULT 'reported',
  vendor        text,
  cost_cents    integer,
  created_at    timestamptz NOT NULL DEFAULT now(),
  resolved_at   timestamptz
);

-- ========== PROJECTS ==========
CREATE TABLE projects (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id     uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  name          text NOT NULL,
  due_date      date,
  status        text NOT NULL DEFAULT 'open',
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- ========== SCAN LOG (audit of every warehouse scan) ==========
CREATE TABLE scans (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scanned_by    uuid REFERENCES staff_users(id) ON DELETE SET NULL,
  scan_type     text NOT NULL,         -- asset_tag | serial | shipping_label | bin
  scan_method   text NOT NULL,         -- scanner_manual | barcode_camera | qr
  value         text NOT NULL,
  device_id     uuid REFERENCES devices(id) ON DELETE SET NULL,
  shipment_id   uuid REFERENCES shipments(id) ON DELETE SET NULL,
  bin_id        uuid REFERENCES bins(id) ON DELETE SET NULL,
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- ========== INDEXES (these back the dashboard card queries) ==========
CREATE INDEX idx_requests_client_type_status  ON requests(client_id, type, status);
CREATE INDEX idx_shipments_client_kind_status ON shipments(client_id, kind, status);
CREATE INDEX idx_devices_status               ON devices(status);
CREATE INDEX idx_devices_assigned_user        ON devices(assigned_user_id);
CREATE INDEX idx_end_users_client             ON end_users(client_id);
CREATE INDEX idx_repairs_status               ON repairs(status);
CREATE INDEX idx_projects_due                 ON projects(due_date);

-- ============================================================
-- Example queries that populate the dashboard cards
-- ============================================================

-- "Rippling Builds" card (Device | End User | Client)
-- SELECT d.asset_tag AS device, eu.full_name AS end_user, c.name AS client
-- FROM requests r
-- JOIN clients c   ON c.id = r.client_id AND c.is_rippling
-- LEFT JOIN devices d   ON d.id = r.device_id
-- LEFT JOIN end_users eu ON eu.id = r.end_user_id
-- WHERE r.type = 'onboarding' AND r.status IN ('open','in_progress');

-- "Rippling Return Boxes" card (Box Type | Tracking | Client)
-- SELECT s.box_type, s.tracking_number, c.name AS client
-- FROM shipments s
-- JOIN clients c ON c.id = s.client_id AND c.is_rippling
-- WHERE s.kind = 'return_box' AND s.status <> 'received';

-- "Projects Due Today" card (Project | Due)
-- SELECT name AS project, due_date AS due
-- FROM projects
-- WHERE status = 'open' AND due_date = CURRENT_DATE;
