# FleetForge — device logistics dashboard (prototype)

A DoneBoard-style platform for managing client devices (laptops, phones, monitors):
onboarding builds, monitor sends, return boxes, repairs, and warehouse scanning.

## Files

| File | What it is |
|------|------------|
| `fleetforge.html` | The full front-end. Open it directly in a browser — no build step. Dashboard cards, the "Choose Scan Type" modal, and live scan lookups all run against a mock data layer. |
| `fleetforge_schema.sql` | PostgreSQL data model (tables, enums, indexes) plus the example queries that back each dashboard card. |

## Running the front-end

Just open `fleetforge.html` in any modern browser. It is self-contained.

### Try it
- Cards load demo data (e.g. "Rippling Builds" shows two devices).
- Click **Scan** in the sidebar → pick a type → look up a value:
  - Asset Tag: `FF-10293`
  - Serial Number: `C02ABC123`
  - Shipping Label: `1Z999AA10123456784`
  - Bin: `BIN-A3-B`

## Wiring it to a real backend

The top of the `<script>` block in `fleetforge.html` has a **DATA LAYER** section
with two functions. To go live, swap the mock returns for real calls:

```js
async function fetchCard(key){
  return (await fetch(`/api/dashboards/${key}`)).json();   // runs the SQL per card
}
async function scanLookup(type, value){
  return (await fetch(`/api/scan/${type}?q=${encodeURIComponent(value)}`)).json();
}
```

Build a backend (Node/Express, Python/FastAPI, etc.) that serves those endpoints
against `fleetforge_schema.sql`. The JSON shapes already match the columns.
Scope every query by the logged-in user's client/tenant so clients can't see
each other's devices.
